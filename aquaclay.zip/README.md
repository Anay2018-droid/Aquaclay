# AquaClay 💧🫧

> **A tactile daily water intake tracker with claymorphic & water aesthetics, fluffy UI components, and soft pastel colors.**

AquaClay turns hydration into a delightful daily ritual. Built using **Jetpack Compose** and **Material Design 3**, it blends soft clay textures, pillowy touch components, spring bounce physics, and fluid wave animations to make tracking your daily water intake satisfying and fun.

---

## ✨ Features

- **🏺 Claymorphic & Fluid Wave Visuals**:
  - Live animated water vessel featuring dual oscillating sine waves and rising bubbles.
  - Tactile squishy buttons with spring-physics feedback.
  - Soft pastel color palette (powder sky blue, fresh mint, peach, lilac, and airy cloud surfaces).

- **⚡ Fast & Custom Logging**:
  - One-tap quick presets: `+150ml`, `+250ml`, `+350ml`, `+500ml`.
  - Custom drink slider (50ml – 1,500ml) with fine-tuning step buttons.
  - Multi-beverage support with custom hydration factors and emojis:
    - 💧 Pure Water
    - 🍵 Herbal Tea
    - 🍋 Lemon Water
    - 🥥 Coconut Water
    - 🫧 Sparkling Water
    - 🧃 Fresh Juice

- **⏰ Smart Custom Reminders**:
  - Configurable reminder intervals (30m, 45m, 1h, 90m, 2h, 3h).
  - Quiet sleep hours (configurable Wake-up & Bedtime window).
  - Actionable system notifications with a direct `+250ml Glass` quick-log action.
  - Built-in "Send Test Reminder Now" button to preview alerts.

- **📊 Analytics & Streaks**:
  - Interactive 7-day clay pillar chart displaying intake vs daily goals.
  - Active daily streak counter.
  - Lifetime volume metrics and beverage distribution breakdown.

- **🎯 Smart Body Hydration Calculator**:
  - Automatically calculates recommended daily target based on body weight, daily activity level, and climate conditions.

- **💾 Local Persistence**:
  - Powered by Android's **Room Database** for offline-first, private data storage.

---

## 🛠️ Tech Stack & Architecture

- **Language**: Kotlin (100%)
- **UI Toolkit**: Jetpack Compose (Material 3)
- **Architecture**: MVVM (Model-View-ViewModel) + Clean Data Layer
- **Local Database**: Room (SQLite) with KSP
- **Asynchronous**: Kotlin Coroutines & Flow / StateFlow
- **Notifications & Scheduling**: `AlarmManager`, `BroadcastReceiver`, `NotificationCompat`
- **Target SDK**: Android 14+ (API 34/36)
- **Minimum SDK**: Android 7.0 (API 24)

---

## 📂 Project Structure

```text
├── app/
│   ├── src/main/
│   │   ├── AndroidManifest.xml
│   │   ├── java/com/example/
│   │   │   ├── AquaClayApplication.kt          # App instance & notification channels
│   │   │   ├── MainActivity.kt                 # Main entrypoint & clay bottom navigation
│   │   │   ├── data/
│   │   │   │   ├── model/                      # WaterLog, UserSettings, BeverageType
│   │   │   │   ├── dao/                        # Room DAOs (WaterLogDao, UserSettingsDao)
│   │   │   │   ├── database/                   # Room AquaDatabase & Converters
│   │   │   │   └── repository/                 # WaterRepository
│   │   │   ├── reminder/
│   │   │   │   ├── ReminderScheduler.kt        # AlarmManager scheduling logic
│   │   │   │   ├── WaterReminderReceiver.kt    # Notification trigger receiver
│   │   │   │   └── QuickLogReceiver.kt         # Notification action handler
│   │   │   └── ui/
│   │   │       ├── MainViewModel.kt            # State orchestration & business logic
│   │   │       ├── clay/ClayStyles.kt          # ClayCard, ClayButton, FluffyPill
│   │   │       ├── components/                 # Water vessel, chart, quick add, dialogs
│   │   │       ├── screens/                    # HomeScreen, StatsScreen, RemindersScreen, GoalCalculatorScreen
│   │   │       └── theme/                      # Soft pastel theme & M3 color scheme
│   │   └── res/                                # Adaptive icons, strings, colors
└── build.gradle.kts                            # Root build config
```

---

## 🚀 Getting Started

### Prerequisites

- Android Studio Iguana / Ladybug or newer
- JDK 17 or higher
- Android SDK with platform API 34+

### Clone & Build

```bash
# Clone the repository
git clone https://github.com/your-username/aquaclay.git

# Navigate into the project
cd aquaclay

# Build debug APK
./gradlew assembleDebug

# Run unit tests
./gradlew testDebugUnitTest
```

The compiled APK will be located at:
`app/build/outputs/apk/debug/app-debug.apk`

---

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.
