package com.example

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.example.data.database.AquaDatabase
import com.example.data.repository.WaterRepository

class AquaClayApplication : Application() {

    lateinit var database: AquaDatabase
        private set

    lateinit var repository: WaterRepository
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this

        database = AquaDatabase.getDatabase(this)
        repository = WaterRepository(
            database.waterLogDao(),
            database.userSettingsDao()
        )

        createNotificationChannel()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channelName = "Hydration Reminders"
            val channelDescription = "Reminders to stay hydrated throughout the day"
            val importance = NotificationManager.IMPORTANCE_HIGH
            val channel = NotificationChannel(
                NOTIFICATION_CHANNEL_ID,
                channelName,
                importance
            ).apply {
                description = channelDescription
                enableVibration(true)
            }

            val notificationManager = getSystemService(NotificationManager::class.java)
            notificationManager?.createNotificationChannel(channel)
        }
    }

    companion object {
        const val NOTIFICATION_CHANNEL_ID = "aqua_clay_reminders"
        lateinit var instance: AquaClayApplication
            private set
    }
}
