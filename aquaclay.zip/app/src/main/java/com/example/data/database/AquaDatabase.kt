package com.example.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import com.example.data.dao.UserSettingsDao
import com.example.data.dao.WaterLogDao
import com.example.data.model.BeverageType
import com.example.data.model.UserSettings
import com.example.data.model.WaterLog

class Converters {
    @TypeConverter
    fun fromBeverageType(value: BeverageType): String {
        return value.name
    }

    @TypeConverter
    fun toBeverageType(value: String): BeverageType {
        return BeverageType.fromName(value)
    }
}

@Database(
    entities = [WaterLog::class, UserSettings::class],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AquaDatabase : RoomDatabase() {
    abstract fun waterLogDao(): WaterLogDao
    abstract fun userSettingsDao(): UserSettingsDao

    companion object {
        @Volatile
        private var INSTANCE: AquaDatabase? = null

        fun getDatabase(context: Context): AquaDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AquaDatabase::class.java,
                    "aqua_clay_database"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
