package com.example.data.model

enum class BeverageType(
    val displayName: String,
    val emoji: String,
    val hydrationFactor: Float,
    val accentHex: Long
) {
    WATER("Pure Water", "💧", 1.0f, 0xFF38BDF8),
    TEA("Herbal Tea", "🍵", 0.95f, 0xFF34D399),
    LEMON("Lemon Water", "🍋", 1.0f, 0xFFFBBF24),
    COCONUT("Coconut Water", "🥥", 1.05f, 0xFFF97316),
    SPARKLING("Sparkling", "🫧", 1.0f, 0xFFA855F7),
    JUICE("Fresh Juice", "🧃", 0.85f, 0xFFEC4899);

    companion object {
        fun fromName(name: String?): BeverageType {
            return entries.firstOrNull { it.name.equals(name, ignoreCase = true) } ?: WATER
        }
    }
}
