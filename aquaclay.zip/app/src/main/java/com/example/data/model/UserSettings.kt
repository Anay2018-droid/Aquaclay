package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_settings")
data class UserSettings(
    @PrimaryKey
    val id: Int = 1,
    val dailyGoalMl: Int = 2200,
    val reminderEnabled: Boolean = true,
    val reminderIntervalMinutes: Int = 90,
    val wakeHour: Int = 8,
    val wakeMinute: Int = 0,
    val sleepHour: Int = 22,
    val sleepMinute: Int = 0,
    val vibrateEnabled: Boolean = true,
    val soundEnabled: Boolean = true,
    val userWeightKg: Int = 68,
    val activityLevel: String = "Moderate" // Sedentary, Moderate, Active, Athlete
)
