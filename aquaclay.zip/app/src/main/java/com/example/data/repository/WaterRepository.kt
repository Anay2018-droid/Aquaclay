package com.example.data.repository

import com.example.data.dao.UserSettingsDao
import com.example.data.dao.WaterLogDao
import com.example.data.model.BeverageType
import com.example.data.model.UserSettings
import com.example.data.model.WaterLog
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class WaterRepository(
    private val waterLogDao: WaterLogDao,
    private val userSettingsDao: UserSettingsDao
) {
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())

    fun getTodayDateString(): String = dateFormat.format(Date())

    fun formatDate(timestamp: Long): String = dateFormat.format(Date(timestamp))

    val allLogs: Flow<List<WaterLog>> = waterLogDao.getAllLogs()

    fun getLogsForDate(date: String): Flow<List<WaterLog>> =
        waterLogDao.getLogsForDate(date)

    fun getTotalIntakeForDate(date: String): Flow<Int> =
        waterLogDao.getTotalIntakeForDate(date).map { it ?: 0 }

    fun getLogsForDateRange(startDate: String, endDate: String): Flow<List<WaterLog>> =
        waterLogDao.getLogsForDateRange(startDate, endDate)

    val userSettings: Flow<UserSettings> = userSettingsDao.getSettings().map {
        it ?: UserSettings()
    }

    suspend fun getUserSettingsSync(): UserSettings {
        return userSettingsDao.getSettingsSync() ?: UserSettings()
    }

    suspend fun insertLog(
        amountMl: Int,
        beverageType: BeverageType = BeverageType.WATER,
        timestamp: Long = System.currentTimeMillis()
    ): Long {
        val dateString = formatDate(timestamp)
        val log = WaterLog(
            amountMl = amountMl,
            beverageType = beverageType,
            timestamp = timestamp,
            dateString = dateString
        )
        return waterLogDao.insertLog(log)
    }

    suspend fun deleteLog(log: WaterLog) {
        waterLogDao.deleteLog(log)
    }

    suspend fun deleteLogById(id: Long) {
        waterLogDao.deleteLogById(id)
    }

    suspend fun saveSettings(settings: UserSettings) {
        userSettingsDao.saveSettings(settings)
    }

    suspend fun clearAll() {
        waterLogDao.clearAll()
    }

    /**
     * Calculates recommended daily hydration in ml based on weight, activity, and climate.
     */
    fun calculateRecommendedGoal(
        weightKg: Int,
        activityLevel: String,
        climateHot: Boolean
    ): Int {
        // Base: 35 ml per kg of body weight
        var baseMl = weightKg * 35

        // Activity addition
        baseMl += when (activityLevel.lowercase(Locale.ROOT)) {
            "sedentary" -> 0
            "light" -> 250
            "moderate" -> 500
            "active" -> 800
            "athlete" -> 1200
            else -> 400
        }

        // Climate factor
        if (climateHot) {
            baseMl += 400
        }

        // Round to nearest 50 ml and clamp between 1200 and 5000 ml
        val rounded = ((baseMl + 25) / 50) * 50
        return rounded.coerceIn(1200, 5000)
    }

    fun getPastDaysDateStrings(days: Int): List<String> {
        val list = mutableListOf<String>()
        val cal = Calendar.getInstance()
        for (i in (days - 1) downTo 0) {
            val targetCal = Calendar.getInstance().apply {
                time = cal.time
                add(Calendar.DAY_OF_YEAR, -i)
            }
            list.add(dateFormat.format(targetCal.time))
        }
        return list
    }
}
