package com.example.reminder

import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.core.app.NotificationCompat
import com.example.AquaClayApplication
import com.example.data.model.BeverageType
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class QuickLogReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val amount = intent.getIntExtra(EXTRA_AMOUNT, 250)
        val app = context.applicationContext as? AquaClayApplication ?: return

        CoroutineScope(Dispatchers.IO).launch {
            app.repository.insertLog(
                amountMl = amount,
                beverageType = BeverageType.WATER,
                timestamp = System.currentTimeMillis()
            )

            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            if (notificationManager != null) {
                val updatedNotification = NotificationCompat.Builder(
                    context,
                    AquaClayApplication.NOTIFICATION_CHANNEL_ID
                )
                    .setSmallIcon(android.R.drawable.ic_menu_compass)
                    .setContentTitle("Awesome! 💧")
                    .setContentText("Added +${amount}ml to your daily hydration!")
                    .setPriority(NotificationCompat.PRIORITY_LOW)
                    .setAutoCancel(true)
                    .setTimeoutAfter(3000)
                    .build()

                notificationManager.notify(WaterReminderReceiver.NOTIFICATION_ID, updatedNotification)
            }

            Handler(Looper.getMainLooper()).post {
                Toast.makeText(context, "+${amount}ml logged! 💧", Toast.LENGTH_SHORT).show()
            }
        }
    }

    companion object {
        const val ACTION_QUICK_LOG = "com.example.aquaclay.ACTION_QUICK_LOG"
        const val EXTRA_AMOUNT = "extra_amount"
    }
}
