package com.example.reminder

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import com.example.data.model.UserSettings
import java.util.Calendar

object ReminderScheduler {
    private const val REQUEST_CODE = 9921

    fun scheduleNextReminder(context: Context, settings: UserSettings) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return

        if (!settings.reminderEnabled) {
            cancelReminder(context)
            return
        }

        val nextTriggerMillis = calculateNextTriggerTime(settings)

        val intent = Intent(context, WaterReminderReceiver::class.java).apply {
            action = WaterReminderReceiver.ACTION_WATER_REMINDER
        }

        val pendingIntent = PendingIntent.getBroadcast(
            context,
            REQUEST_CODE,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    nextTriggerMillis,
                    pendingIntent
                )
            } else {
                alarmManager.set(
                    AlarmManager.RTC_WAKEUP,
                    nextTriggerMillis,
                    pendingIntent
                )
            }
            Log.d("ReminderScheduler", "Scheduled next water reminder for timestamp: $nextTriggerMillis")
        } catch (e: SecurityException) {
            Log.e("ReminderScheduler", "Exact alarm permission missing, fallback to set()", e)
            alarmManager.set(
                AlarmManager.RTC_WAKEUP,
                nextTriggerMillis,
                pendingIntent
            )
        }
    }

    fun cancelReminder(context: Context) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val intent = Intent(context, WaterReminderReceiver::class.java).apply {
            action = WaterReminderReceiver.ACTION_WATER_REMINDER
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            REQUEST_CODE,
            intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pendingIntent != null) {
            alarmManager.cancel(pendingIntent)
            pendingIntent.cancel()
        }
    }

    private fun calculateNextTriggerTime(settings: UserSettings): Long {
        val now = Calendar.getInstance()
        val intervalMs = (settings.reminderIntervalMinutes.coerceAtLeast(15)) * 60 * 1000L

        // Current time plus interval
        val candidate = Calendar.getInstance().apply {
            timeInMillis = now.timeInMillis + intervalMs
        }

        val candidateHour = candidate.get(Calendar.HOUR_OF_DAY)
        val candidateMinute = candidate.get(Calendar.MINUTE)
        val candidateMinutesOfDay = candidateHour * 60 + candidateMinute

        val wakeMinutesOfDay = settings.wakeHour * 60 + settings.wakeMinute
        val sleepMinutesOfDay = settings.sleepHour * 60 + settings.sleepMinute

        // If candidate falls within active waking hours:
        if (candidateMinutesOfDay in wakeMinutesOfDay..sleepMinutesOfDay) {
            return candidate.timeInMillis
        }

        // If candidate falls outside waking hours (i.e. night time), schedule for tomorrow wake time
        val nextWake = Calendar.getInstance().apply {
            if (candidateMinutesOfDay > sleepMinutesOfDay) {
                add(Calendar.DAY_OF_YEAR, 1)
            }
            set(Calendar.HOUR_OF_DAY, settings.wakeHour)
            set(Calendar.MINUTE, settings.wakeMinute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

        // If today's wake time is already past and candidate is earlier than wake time:
        if (nextWake.timeInMillis <= now.timeInMillis) {
            nextWake.add(Calendar.DAY_OF_YEAR, 1)
        }

        return nextWake.timeInMillis
    }
}
