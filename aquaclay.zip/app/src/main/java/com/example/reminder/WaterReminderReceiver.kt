package com.example.reminder

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.example.AquaClayApplication
import com.example.MainActivity
import com.example.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class WaterReminderReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val app = context.applicationContext as? AquaClayApplication ?: return

        CoroutineScope(Dispatchers.IO).launch {
            val settings = app.repository.getUserSettingsSync()
            if (!settings.reminderEnabled) return@launch

            showNotification(context, settings.vibrateEnabled, settings.soundEnabled)
            // Schedule next interval
            ReminderScheduler.scheduleNextReminder(context, settings)
        }
    }

    private fun showNotification(context: Context, vibrate: Boolean, sound: Boolean) {
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            ?: return

        // Intent to open app
        val openAppIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openAppPendingIntent = PendingIntent.getActivity(
            context,
            1001,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Intent to quick log +250ml
        val quickLogIntent = Intent(context, QuickLogReceiver::class.java).apply {
            action = QuickLogReceiver.ACTION_QUICK_LOG
            putExtra(QuickLogReceiver.EXTRA_AMOUNT, 250)
        }
        val quickLogPendingIntent = PendingIntent.getBroadcast(
            context,
            1002,
            quickLogIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val tips = listOf(
            "Time for a fresh sip! Hydration keeps your clay pottery soft and flexible. 💧",
            "Drink a glass of water now to boost your focus and clear energy! 🌊",
            "Your body is asking for hydration! Tap below to log 250ml. 🫧",
            "A splash of water keeps your glow alive today! Sip up! ✨"
        )
        val selectedTip = tips.random()

        val builder = NotificationCompat.Builder(context, AquaClayApplication.NOTIFICATION_CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_compass) // or app icon
            .setContentTitle("Sip Time! 💧 Stay Hydrated")
            .setContentText(selectedTip)
            .setStyle(NotificationCompat.BigTextStyle().bigText(selectedTip))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(openAppPendingIntent)
            .setAutoCancel(true)
            .addAction(
                android.R.drawable.ic_input_add,
                "+250ml Glass",
                quickLogPendingIntent
            )

        if (vibrate) {
            builder.setVibrate(longArrayOf(0, 250, 150, 250))
        }

        notificationManager.notify(NOTIFICATION_ID, builder.build())
    }

    companion object {
        const val ACTION_WATER_REMINDER = "com.example.aquaclay.ACTION_WATER_REMINDER"
        const val NOTIFICATION_ID = 5543
    }
}
