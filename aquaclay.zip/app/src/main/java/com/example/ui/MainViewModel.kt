package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.AquaClayApplication
import com.example.data.model.BeverageType
import com.example.data.model.UserSettings
import com.example.data.model.WaterLog
import com.example.reminder.ReminderScheduler
import com.example.ui.components.DayIntakeData
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = (application as AquaClayApplication).repository

    val todayDateString: String = repository.getTodayDateString()

    // Selected date for viewing history / chart
    private val _selectedDate = MutableStateFlow(todayDateString)
    val selectedDate: StateFlow<String> = _selectedDate.asStateFlow()

    // Selected beverage for quick adding
    private val _selectedBeverage = MutableStateFlow(BeverageType.WATER)
    val selectedBeverage: StateFlow<BeverageType> = _selectedBeverage.asStateFlow()

    // Show custom add dialog state
    private val _showCustomAddDialog = MutableStateFlow(false)
    val showCustomAddDialog: StateFlow<Boolean> = _showCustomAddDialog.asStateFlow()

    // User settings flow
    val userSettings: StateFlow<UserSettings> = repository.userSettings.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = UserSettings()
    )

    // Today's logs
    val todayLogs: StateFlow<List<WaterLog>> = repository.getLogsForDate(todayDateString).stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Today's total intake
    val todayTotalIntake: StateFlow<Int> = repository.getTotalIntakeForDate(todayDateString).stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = 0
    )

    // Selected date logs
    private val _selectedDateLogs = MutableStateFlow<List<WaterLog>>(emptyList())
    val selectedDateLogs: StateFlow<List<WaterLog>> = _selectedDateLogs.asStateFlow()

    // All logs for analytics
    val allLogs: StateFlow<List<WaterLog>> = repository.allLogs.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Weekly intake data for the 7-day chart
    val weeklyData: StateFlow<List<DayIntakeData>> = combine(
        allLogs,
        userSettings
    ) { logs, settings ->
        val past7Days = repository.getPastDaysDateStrings(7)
        val dayLabelFormat = SimpleDateFormat("EEE", Locale.getDefault())
        val parseFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())

        past7Days.map { dateStr ->
            val dayLogs = logs.filter { it.dateString == dateStr }
            val total = dayLogs.sumOf { it.amountMl }
            val dateObj = parseFormat.parse(dateStr) ?: Date()
            val dayLabel = dayLabelFormat.format(dateObj)

            DayIntakeData(
                dayLabel = dayLabel,
                dateString = dateStr,
                totalMl = total,
                goalMl = settings.dailyGoalMl,
                isToday = dateStr == todayDateString
            )
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Current streak calculation
    val currentStreak: StateFlow<Int> = combine(
        allLogs,
        userSettings
    ) { logs, settings ->
        calculateStreak(logs, settings.dailyGoalMl)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = 0
    )

    init {
        // Observe selectedDate changes and update selectedDateLogs
        viewModelScope.launch {
            selectedDate.collect { date ->
                repository.getLogsForDate(date).collect { logs ->
                    _selectedDateLogs.value = logs
                }
            }
        }
    }

    fun selectDate(date: String) {
        _selectedDate.value = date
    }

    fun selectBeverage(beverage: BeverageType) {
        _selectedBeverage.value = beverage
    }

    fun setCustomAddDialogVisible(visible: Boolean) {
        _showCustomAddDialog.value = visible
    }

    fun logWater(amountMl: Int, beverage: BeverageType = _selectedBeverage.value) {
        viewModelScope.launch {
            repository.insertLog(
                amountMl = amountMl,
                beverageType = beverage,
                timestamp = System.currentTimeMillis()
            )
        }
    }

    fun deleteLog(log: WaterLog) {
        viewModelScope.launch {
            repository.deleteLog(log)
        }
    }

    fun updateSettings(newSettings: UserSettings) {
        viewModelScope.launch {
            repository.saveSettings(newSettings)
            // Reschedule reminders with new settings
            ReminderScheduler.scheduleNextReminder(getApplication(), newSettings)
        }
    }

    fun updateDailyGoal(goalMl: Int) {
        val current = userSettings.value
        updateSettings(current.copy(dailyGoalMl = goalMl))
    }

    fun toggleReminders(enabled: Boolean) {
        val current = userSettings.value
        updateSettings(current.copy(reminderEnabled = enabled))
    }

    fun setReminderInterval(minutes: Int) {
        val current = userSettings.value
        updateSettings(current.copy(reminderIntervalMinutes = minutes))
    }

    fun setWakeSleepTimes(wakeHour: Int, wakeMinute: Int, sleepHour: Int, sleepMinute: Int) {
        val current = userSettings.value
        updateSettings(
            current.copy(
                wakeHour = wakeHour,
                wakeMinute = wakeMinute,
                sleepHour = sleepHour,
                sleepMinute = sleepMinute
            )
        )
    }

    fun calculateRecommendedGoal(weightKg: Int, activity: String, isHotClimate: Boolean): Int {
        return repository.calculateRecommendedGoal(weightKg, activity, isHotClimate)
    }

    private fun calculateStreak(logs: List<WaterLog>, goalMl: Int): Int {
        if (logs.isEmpty() || goalMl <= 0) return 0
        val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())

        val dailyTotals = logs.groupBy { it.dateString }
            .mapValues { entry -> entry.value.sumOf { it.amountMl } }

        var streak = 0
        val cal = Calendar.getInstance()

        // Check today first
        val todayStr = dateFormat.format(cal.time)
        val todayTotal = dailyTotals[todayStr] ?: 0
        if (todayTotal >= goalMl) {
            streak++
        }

        // Check previous consecutive days
        while (true) {
            cal.add(Calendar.DAY_OF_YEAR, -1)
            val prevDateStr = dateFormat.format(cal.time)
            val prevTotal = dailyTotals[prevDateStr] ?: 0
            if (prevTotal >= goalMl) {
                streak++
            } else {
                break
            }
        }

        return streak
    }
}
