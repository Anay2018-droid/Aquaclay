package com.example.ui.clay

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.ClayShadowDark
import com.example.ui.theme.ClayShadowLight

/**
 * High-fidelity Claymorphic Card with soft dual shadow, subtle inner highlight,
 * and pillowy rounded corners.
 */
@Composable
fun ClayCard(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(28.dp),
    backgroundColor: Color = Color.White,
    borderColor: Color = Color(0xFFF1F5F9),
    elevation: Dp = 8.dp,
    content: @Composable BoxScope.() -> Unit
) {
    Box(
        modifier = modifier
            .shadow(
                elevation = elevation,
                shape = shape,
                ambientColor = ClayShadowDark,
                spotColor = ClayShadowDark
            )
            .clip(shape)
            .background(backgroundColor)
            .border(
                width = 1.5.dp,
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.9f),
                        borderColor
                    )
                ),
                shape = shape
            )
            // Subtle clay highlight drawing at the top rim
            .drawBehind {
                drawCircle(
                    color = Color.White.copy(alpha = 0.35f),
                    radius = size.width * 0.45f,
                    center = Offset(size.width * 0.2f, size.height * 0.05f)
                )
            },
        content = content
    )
}

/**
 * Tactile Squishy Clay Button with gentle spring bounce press physics.
 */
@Composable
fun ClayButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(24.dp),
    backgroundColor: Color = Color(0xFF0284C7),
    contentColor: Color = Color.White,
    elevation: Dp = 6.dp,
    enabled: Boolean = true,
    content: @Composable BoxScope.() -> Unit
) {
    var isPressed by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.94f else 1.0f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "clay_press_scale"
    )

    Box(
        modifier = modifier
            .scale(scale)
            .pointerInput(enabled) {
                if (enabled) {
                    awaitEachGesture {
                        awaitFirstDown(requireUnconsumed = false)
                        isPressed = true
                        val up = waitForUpOrCancellation()
                        isPressed = false
                        if (up != null) {
                            onClick()
                        }
                    }
                }
            }
            .shadow(
                elevation = if (isPressed) 2.dp else elevation,
                shape = shape,
                ambientColor = ClayShadowDark,
                spotColor = ClayShadowDark
            )
            .clip(shape)
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        backgroundColor.copy(alpha = 0.95f),
                        backgroundColor
                    )
                )
            )
            .border(
                width = 1.5.dp,
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.6f),
                        Color.Transparent
                    )
                ),
                shape = shape
            ),
        contentAlignment = Alignment.Center,
        content = content
    )
}

/**
 * Fluffy interactive pill chip for preset amounts and filters.
 */
@Composable
fun FluffyPill(
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(20.dp),
    selectedColor: Color = Color(0xFF38BDF8),
    unselectedColor: Color = Color.White,
    content: @Composable BoxScope.() -> Unit
) {
    var isPressed by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.93f else 1.0f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "pill_scale"
    )

    Box(
        modifier = modifier
            .scale(scale)
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    isPressed = true
                    val up = waitForUpOrCancellation()
                    isPressed = false
                    if (up != null) {
                        onClick()
                    }
                }
            }
            .shadow(
                elevation = if (selected) 6.dp else 2.dp,
                shape = shape,
                ambientColor = if (selected) Color(0x330284C7) else Color(0x15000000),
                spotColor = if (selected) Color(0x440284C7) else Color(0x15000000)
            )
            .clip(shape)
            .background(if (selected) selectedColor else unselectedColor)
            .border(
                width = if (selected) 2.dp else 1.dp,
                brush = Brush.verticalGradient(
                    colors = if (selected) {
                        listOf(Color.White.copy(alpha = 0.8f), selectedColor)
                    } else {
                        listOf(Color.White, Color(0xFFE2E8F0))
                    }
                ),
                shape = shape
            ),
        contentAlignment = Alignment.Center,
        content = content
    )
}
