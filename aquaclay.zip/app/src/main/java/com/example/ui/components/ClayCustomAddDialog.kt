package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.BeverageType
import com.example.ui.clay.ClayButton
import com.example.ui.clay.ClayCard
import com.example.ui.clay.FluffyPill
import com.example.ui.theme.TextSlateMuted
import com.example.ui.theme.TextSlatePrimary
import com.example.ui.theme.WaterDarkDeep
import com.example.ui.theme.WaterPastelSky
import com.example.ui.theme.WaterPrimary

@Composable
fun ClayCustomAddDialog(
    initialAmount: Int = 300,
    initialBeverage: BeverageType = BeverageType.WATER,
    onDismiss: () -> Unit,
    onConfirm: (amountMl: Int, beverage: BeverageType) -> Unit
) {
    var amount by remember { mutableFloatStateOf(initialAmount.toFloat()) }
    var selectedBeverage by remember { mutableStateOf(initialBeverage) }

    Dialog(onDismissRequest = onDismiss) {
        ClayCard(
            modifier = Modifier
                .testTag("custom_add_dialog")
                .fillMaxWidth(),
            shape = RoundedCornerShape(36.dp),
            backgroundColor = Color.White,
            elevation = 16.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header with close button
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Log Custom Drink",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextSlatePrimary
                    )
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFF1F5F9))
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Close,
                            contentDescription = "Close",
                            tint = TextSlateMuted,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Beverage selector
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    BeverageType.entries.forEach { bev ->
                        val isSelected = bev == selectedBeverage
                        FluffyPill(
                            selected = isSelected,
                            onClick = { selectedBeverage = bev },
                            selectedColor = Color(bev.accentHex),
                            shape = RoundedCornerShape(18.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(text = bev.emoji, fontSize = 13.sp)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = bev.displayName,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    color = if (isSelected) Color.White else TextSlatePrimary
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Fluffy Amount Display
                Box(
                    modifier = Modifier
                        .shadow(6.dp, RoundedCornerShape(24.dp), ambientColor = Color(0x220284C7))
                        .clip(RoundedCornerShape(24.dp))
                        .background(Color(0xFFF0F9FF))
                        .border(1.5.dp, Color(0xFFBAE6FD), RoundedCornerShape(24.dp))
                        .padding(horizontal = 28.dp, vertical = 14.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.Bottom,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = "${amount.toInt()}",
                            fontSize = 38.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = WaterDarkDeep
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "ml",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = WaterPrimary,
                            modifier = Modifier.padding(bottom = 6.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Plus / Minus Step Buttons
                Row(
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    ClayButton(
                        onClick = { amount = (amount - 50f).coerceAtLeast(50f) },
                        modifier = Modifier.size(46.dp),
                        shape = CircleShape,
                        backgroundColor = Color(0xFFF1F5F9),
                        contentColor = WaterDarkDeep
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Remove,
                            contentDescription = "Decrease 50ml",
                            tint = WaterDarkDeep
                        )
                    }

                    Text(
                        text = "±50 ml",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = TextSlateMuted
                    )

                    ClayButton(
                        onClick = { amount = (amount + 50f).coerceAtMost(1500f) },
                        modifier = Modifier.size(46.dp),
                        shape = CircleShape,
                        backgroundColor = Color(0xFFF1F5F9),
                        contentColor = WaterDarkDeep
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Add,
                            contentDescription = "Increase 50ml",
                            tint = WaterDarkDeep
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Smooth Slider
                Slider(
                    value = amount,
                    onValueChange = { amount = (it / 25).toInt() * 25f },
                    valueRange = 50f..1500f,
                    steps = 57,
                    colors = SliderDefaults.colors(
                        thumbColor = WaterPrimary,
                        activeTrackColor = WaterPrimary,
                        inactiveTrackColor = Color(0xFFE2E8F0)
                    ),
                    modifier = Modifier.padding(horizontal = 8.dp)
                )

                Spacer(modifier = Modifier.height(24.dp))

                // Log Button
                ClayButton(
                    onClick = {
                        onConfirm(amount.toInt(), selectedBeverage)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                        .testTag("confirm_log_button"),
                    backgroundColor = WaterPrimary,
                    shape = RoundedCornerShape(24.dp),
                    elevation = 8.dp
                ) {
                    Text(
                        text = "Log ${amount.toInt()} ml ${selectedBeverage.emoji}",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }
        }
    }
}
