package com.example.ui.components

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.LocalDrink
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BeverageType
import com.example.ui.clay.ClayButton
import com.example.ui.clay.ClayCard
import com.example.ui.clay.FluffyPill
import com.example.ui.theme.PastelMint
import com.example.ui.theme.TextSlateMuted
import com.example.ui.theme.TextSlatePrimary
import com.example.ui.theme.WaterDarkDeep
import com.example.ui.theme.WaterPrimary

@Composable
fun ClayQuickAddRow(
    selectedBeverage: BeverageType,
    onBeverageSelected: (BeverageType) -> Unit,
    onQuickAdd: (Int) -> Unit,
    onCustomAddClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    ClayCard(
        modifier = modifier
            .testTag("quick_add_card")
            .fillMaxWidth(),
        shape = RoundedCornerShape(32.dp),
        backgroundColor = Color.White,
        elevation = 8.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Quick Drink",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextSlatePrimary
                )
                Text(
                    text = "Tap to add",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    color = TextSlateMuted
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Beverage Type Selector (Horizontal scrollable fluffy pills)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                BeverageType.entries.forEach { bev ->
                    val isSelected = bev == selectedBeverage
                    FluffyPill(
                        selected = isSelected,
                        onClick = { onBeverageSelected(bev) },
                        selectedColor = Color(bev.accentHex),
                        modifier = Modifier.testTag("beverage_pill_${bev.name.lowercase()}")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = bev.emoji,
                                fontSize = 14.sp
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = bev.displayName,
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) Color.White else TextSlatePrimary
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Presets row: +150ml, +250ml, +350ml, +500ml, +Custom
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                listOf(150, 250, 350, 500).forEach { amount ->
                    ClayButton(
                        onClick = { onQuickAdd(amount) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("quick_add_${amount}ml"),
                        backgroundColor = Color(0xFFF0F9FF),
                        contentColor = WaterDarkDeep,
                        shape = RoundedCornerShape(20.dp),
                        elevation = 4.dp
                    ) {
                        Column(
                            modifier = Modifier.padding(vertical = 12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.LocalDrink,
                                contentDescription = null,
                                tint = WaterPrimary,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "+$amount",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = WaterDarkDeep
                            )
                            Text(
                                text = "ml",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Medium,
                                color = TextSlateMuted
                            )
                        }
                    }
                }

                // Custom amount button
                ClayButton(
                    onClick = onCustomAddClick,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("quick_add_custom"),
                    backgroundColor = WaterPrimary,
                    contentColor = Color.White,
                    shape = RoundedCornerShape(20.dp),
                    elevation = 6.dp
                ) {
                    Column(
                        modifier = Modifier.padding(vertical = 12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Add,
                            contentDescription = "Custom Amount",
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Custom",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = "ml",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFFBAE6FD)
                        )
                    }
                }
            }
        }
    }
}
