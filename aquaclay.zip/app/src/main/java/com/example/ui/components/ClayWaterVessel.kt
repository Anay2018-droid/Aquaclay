package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.WaterDrop
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.clay.ClayCard
import com.example.ui.theme.PastelMint
import com.example.ui.theme.TextSlateMuted
import com.example.ui.theme.TextSlatePrimary
import com.example.ui.theme.WaterDarkDeep
import com.example.ui.theme.WaterPastelSky
import com.example.ui.theme.WaterPrimary
import com.example.ui.theme.WaterSecondary
import com.example.ui.theme.WaterWaveCrest
import kotlin.math.PI
import kotlin.math.sin

@Composable
fun ClayWaterVessel(
    currentIntakeMl: Int,
    dailyGoalMl: Int,
    onVesselClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val progress = if (dailyGoalMl > 0) {
        (currentIntakeMl.toFloat() / dailyGoalMl.toFloat()).coerceIn(0f, 1.25f)
    } else 0f

    // Animated water height progress
    val animatedProgress by animateFloatAsState(
        targetValue = progress.coerceAtMost(1f),
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "water_fill_anim"
    )

    // Continuous wave oscillation
    val infiniteTransition = rememberInfiniteTransition(label = "wave_oscillation")
    val waveOffset by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 2f * PI.toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2800, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "wave_offset"
    )

    // Gentle floating bubbles oscillation
    val bubbleFloat1 by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 3200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "bubble_1"
    )
    val bubbleFloat2 by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 4100, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "bubble_2"
    )

    val percent = (progress * 100).toInt()

    // Vessel Outer Clay Container
    ClayCard(
        modifier = modifier
            .testTag("water_vessel_card")
            .fillMaxWidth()
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) { onVesselClick() },
        shape = RoundedCornerShape(36.dp),
        backgroundColor = Color.White,
        elevation = 12.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 24.dp, horizontal = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Header with status message
            val statusText = when {
                progress >= 1.0f -> "Goal Smashed! 🎉 Perfect Hydration"
                progress >= 0.75f -> "Almost There! 💧 Keep Flowing"
                progress >= 0.40f -> "Great Rhythm! 🌊 Feeling Refreshed"
                progress >= 0.15f -> "Good Start! 🫧 Drink More Sips"
                else -> "Time to hydrate! 🌱 Start your day"
            }

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFFF0F9FF))
                    .border(1.dp, Color(0xFFBAE6FD), RoundedCornerShape(16.dp))
                    .padding(horizontal = 14.dp, vertical = 6.dp)
            ) {
                Text(
                    text = statusText,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = WaterDarkDeep
                )
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Fluffy Rounded Clay Vessel with Animated Water Wave
            Box(
                modifier = Modifier
                    .size(width = 210.dp, height = 230.dp)
                    .shadow(
                        elevation = 16.dp,
                        shape = RoundedCornerShape(topStart = 80.dp, topEnd = 80.dp, bottomStart = 70.dp, bottomEnd = 70.dp),
                        ambientColor = Color(0x330284C7),
                        spotColor = Color(0x330284C7)
                    )
                    .clip(RoundedCornerShape(topStart = 80.dp, topEnd = 80.dp, bottomStart = 70.dp, bottomEnd = 70.dp))
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color(0xFFF8FAFC),
                                Color(0xFFEDF2F7)
                            )
                        )
                    )
                    .border(
                        width = 4.dp,
                        brush = Brush.verticalGradient(
                            colors = listOf(
                                Color.White,
                                Color(0xFFBAE6FD),
                                Color(0xFFE2E8F0)
                            )
                        ),
                        shape = RoundedCornerShape(topStart = 80.dp, topEnd = 80.dp, bottomStart = 70.dp, bottomEnd = 70.dp)
                    )
            ) {
                // Wave Canvas
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val canvasWidth = size.width
                    val canvasHeight = size.height

                    // Calculate base water level Y (0 = bottom, 1 = top)
                    // If progress is 0, give tiny 4% bottom pool so it still looks alive
                    val effectiveProgress = animatedProgress.coerceIn(0.04f, 1f)
                    val baseWaterY = canvasHeight * (1f - effectiveProgress)

                    val waveAmplitude = 12.dp.toPx() * (1f - (animatedProgress - 0.5f).let { it * it * 0.8f })
                    val waveFrequency = (2f * PI / canvasWidth).toFloat()

                    // Back subtle wave path
                    val backWavePath = Path().apply {
                        moveTo(0f, canvasHeight)
                        lineTo(0f, baseWaterY)
                        var x = 0f
                        while (x <= canvasWidth) {
                            val y = baseWaterY + waveAmplitude * 0.7f * sin(waveFrequency * x + waveOffset + 1.2f)
                            lineTo(x, y)
                            x += 8f
                        }
                        lineTo(canvasWidth, canvasHeight)
                        close()
                    }

                    drawPath(
                        path = backWavePath,
                        brush = Brush.verticalGradient(
                            colors = listOf(
                                Color(0xFF7DD3FC).copy(alpha = 0.6f),
                                Color(0xFF0284C7).copy(alpha = 0.7f)
                            ),
                            startY = baseWaterY - waveAmplitude,
                            endY = canvasHeight
                        )
                    )

                    // Front vibrant wave path
                    val frontWavePath = Path().apply {
                        moveTo(0f, canvasHeight)
                        lineTo(0f, baseWaterY)
                        var x = 0f
                        while (x <= canvasWidth) {
                            val y = baseWaterY + waveAmplitude * sin(waveFrequency * x - waveOffset)
                            lineTo(x, y)
                            x += 6f
                        }
                        lineTo(canvasWidth, canvasHeight)
                        close()
                    }

                    drawPath(
                        path = frontWavePath,
                        brush = Brush.verticalGradient(
                            colors = listOf(
                                Color(0xFFBAE6FD),
                                Color(0xFF38BDF8),
                                Color(0xFF0284C7),
                                Color(0xFF0369A1)
                            ),
                            startY = baseWaterY - waveAmplitude,
                            endY = canvasHeight
                        )
                    )

                    // Draw bubbles if water has some height
                    if (effectiveProgress > 0.12f) {
                        val waterDepth = canvasHeight - baseWaterY

                        // Bubble 1
                        val b1Y = canvasHeight - (waterDepth * bubbleFloat1)
                        if (b1Y > baseWaterY + 10f) {
                            val b1X = canvasWidth * 0.35f + sin(bubbleFloat1 * 6f) * 12f
                            drawCircle(
                                color = Color.White.copy(alpha = 0.55f),
                                radius = 7.dp.toPx(),
                                center = Offset(b1X, b1Y)
                            )
                            drawCircle(
                                color = Color.White.copy(alpha = 0.85f),
                                radius = 2.dp.toPx(),
                                center = Offset(b1X - 2.dp.toPx(), b1Y - 2.dp.toPx())
                            )
                        }

                        // Bubble 2
                        val b2Y = canvasHeight - (waterDepth * bubbleFloat2)
                        if (b2Y > baseWaterY + 10f) {
                            val b2X = canvasWidth * 0.65f + sin(bubbleFloat2 * 8f) * 15f
                            drawCircle(
                                color = Color.White.copy(alpha = 0.5f),
                                radius = 5.dp.toPx(),
                                center = Offset(b2X, b2Y)
                            )
                            drawCircle(
                                color = Color.White.copy(alpha = 0.8f),
                                radius = 1.5.dp.toPx(),
                                center = Offset(b2X - 1.5.dp.toPx(), b2Y - 1.5.dp.toPx())
                            )
                        }
                    }

                    // Soft Clay Glass Reflection / Shine (Top-Left Curved Strip)
                    drawArc(
                        color = Color.White.copy(alpha = 0.45f),
                        startAngle = 180f,
                        sweepAngle = 60f,
                        useCenter = false,
                        topLeft = Offset(14.dp.toPx(), 14.dp.toPx()),
                        size = Size(canvasWidth * 0.85f, canvasHeight * 0.85f),
                        style = Stroke(width = 5.dp.toPx())
                    )
                }

                // Center Water Info Overlay
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    // Soft translucent pill backdrop for percentage readout
                    Box(
                        modifier = Modifier
                            .shadow(4.dp, RoundedCornerShape(20.dp), ambientColor = Color(0x22000000))
                            .clip(RoundedCornerShape(20.dp))
                            .background(Color.White.copy(alpha = 0.88f))
                            .border(1.dp, Color.White, RoundedCornerShape(20.dp))
                            .padding(horizontal = 14.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = "$percent%",
                            fontSize = 28.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = WaterDarkDeep
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = "$currentIntakeMl ml",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (animatedProgress > 0.55f) Color.White else TextSlatePrimary
                    )

                    Text(
                        text = "of $dailyGoalMl ml goal",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = if (animatedProgress > 0.55f) Color(0xFFE0F2FE) else TextSlateMuted
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Quick Stats Row: Remaining & Glass Count
            val remainingMl = (dailyGoalMl - currentIntakeMl).coerceAtLeast(0)
            val glasses = (currentIntakeMl / 250)
            val targetGlasses = (dailyGoalMl / 250).coerceAtLeast(1)

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color(0xFFF8FAFC))
                    .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(20.dp))
                    .padding(horizontal = 16.dp, vertical = 10.dp)
            ) {
                androidx.compose.foundation.layout.Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = if (remainingMl > 0) "${remainingMl}ml" else "Met! ✨",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = if (remainingMl > 0) WaterPrimary else Color(0xFF059669)
                        )
                        Text(
                            text = "Remaining",
                            fontSize = 11.sp,
                            color = TextSlateMuted
                        )
                    }

                    Box(
                        modifier = Modifier
                            .size(width = 1.dp, height = 24.dp)
                            .background(Color(0xFFE2E8F0))
                    )

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "$glasses / $targetGlasses",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = TextSlatePrimary
                        )
                        Text(
                            text = "Glasses (250ml)",
                            fontSize = 11.sp,
                            color = TextSlateMuted
                        )
                    }
                }
            }
        }
    }
}
