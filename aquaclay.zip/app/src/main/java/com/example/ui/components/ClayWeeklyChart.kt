package com.example.ui.components

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.clay.ClayCard
import com.example.ui.theme.TextSlateMuted
import com.example.ui.theme.TextSlatePrimary
import com.example.ui.theme.WaterDarkDeep
import com.example.ui.theme.WaterPastelSky
import com.example.ui.theme.WaterPrimary

data class DayIntakeData(
    val dayLabel: String, // e.g. "Mon", "Tue"
    val dateString: String,
    val totalMl: Int,
    val goalMl: Int,
    val isToday: Boolean
)

@Composable
fun ClayWeeklyChart(
    weeklyData: List<DayIntakeData>,
    selectedDate: String,
    onDaySelected: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    ClayCard(
        modifier = modifier
            .testTag("weekly_chart_card")
            .fillMaxWidth(),
        shape = RoundedCornerShape(32.dp),
        backgroundColor = Color.White,
        elevation = 8.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Weekly Hydration",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextSlatePrimary
                    )
                    Text(
                        text = "7-Day intake vs daily goals",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = TextSlateMuted
                    )
                }

                // Average intake pill
                val avgIntake = if (weeklyData.isNotEmpty()) {
                    weeklyData.map { it.totalMl }.average().toInt()
                } else 0
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0xFFF0FDF4))
                        .border(1.dp, Color(0xFFA7F3D0), RoundedCornerShape(14.dp))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "Avg ${avgIntake}ml/d",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF059669)
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Chart Columns Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(170.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                weeklyData.forEach { day ->
                    val isSelected = day.dateString == selectedDate
                    val ratio = if (day.goalMl > 0) {
                        (day.totalMl.toFloat() / day.goalMl.toFloat()).coerceIn(0f, 1.3f)
                    } else 0f

                    val animatedHeightRatio by animateFloatAsState(
                        targetValue = (ratio / 1.3f).coerceIn(0.05f, 1f),
                        animationSpec = spring(
                            dampingRatio = Spring.DampingRatioMediumBouncy,
                            stiffness = Spring.StiffnessLow
                        ),
                        label = "bar_height_${day.dateString}"
                    )

                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { onDaySelected(day.dateString) },
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Bottom
                    ) {
                        // Check badge if met goal
                        if (day.totalMl >= day.goalMl && day.goalMl > 0) {
                            Box(
                                modifier = Modifier
                                    .size(16.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF34D399)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Check,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(11.dp)
                                )
                            }
                        } else {
                            Spacer(modifier = Modifier.size(16.dp))
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        // Pillar Container
                        Box(
                            modifier = Modifier
                                .width(28.dp)
                                .height(110.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background(
                                    if (isSelected) Color(0xFFE0F2FE) else Color(0xFFF1F5F9)
                                )
                                .border(
                                    width = if (isSelected) 2.dp else 1.dp,
                                    color = if (isSelected) WaterPrimary else Color(0xFFE2E8F0),
                                    shape = RoundedCornerShape(14.dp)
                                ),
                            contentAlignment = Alignment.BottomCenter
                        ) {
                            // Filled Water Column
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .fillMaxHeight(animatedHeightRatio)
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(
                                        Brush.verticalGradient(
                                            colors = if (day.totalMl >= day.goalMl) {
                                                listOf(Color(0xFF34D399), Color(0xFF059669))
                                            } else {
                                                listOf(Color(0xFF7DD3FC), Color(0xFF0284C7))
                                            }
                                        )
                                    )
                                    // Top highlight gloss on pillar
                                    .border(
                                        1.dp,
                                        Color.White.copy(alpha = 0.6f),
                                        RoundedCornerShape(14.dp)
                                    )
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Day label & current indicator
                        Text(
                            text = day.dayLabel,
                            fontSize = 11.sp,
                            fontWeight = if (day.isToday) FontWeight.ExtraBold else FontWeight.Medium,
                            color = if (day.isToday) WaterPrimary else TextSlatePrimary
                        )

                        if (day.isToday) {
                            Box(
                                modifier = Modifier
                                    .padding(top = 2.dp)
                                    .size(4.dp)
                                    .clip(CircleShape)
                                    .background(WaterPrimary)
                            )
                        } else {
                            Spacer(modifier = Modifier.height(4.dp))
                        }
                    }
                }
            }
        }
    }
}
