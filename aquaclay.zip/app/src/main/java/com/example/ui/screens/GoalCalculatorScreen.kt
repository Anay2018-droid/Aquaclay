package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Calculate
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.FitnessCenter
import androidx.compose.material.icons.rounded.MonitorWeight
import androidx.compose.material.icons.rounded.Thermostat
import androidx.compose.material.icons.rounded.WaterDrop
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.MainViewModel
import com.example.ui.clay.ClayButton
import com.example.ui.clay.ClayCard
import com.example.ui.clay.FluffyPill
import com.example.ui.theme.PastelMintDark
import com.example.ui.theme.TextSlateMuted
import com.example.ui.theme.TextSlatePrimary
import com.example.ui.theme.WaterDarkDeep
import com.example.ui.theme.WaterPrimary

@Composable
fun GoalCalculatorScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val settings by viewModel.userSettings.collectAsStateWithLifecycle()

    var customGoal by remember(settings.dailyGoalMl) {
        mutableFloatStateOf(settings.dailyGoalMl.toFloat())
    }

    // Calculator states
    var calcWeightKg by remember(settings.userWeightKg) {
        mutableIntStateOf(settings.userWeightKg)
    }
    var calcActivity by remember(settings.activityLevel) {
        mutableStateOf(settings.activityLevel)
    }
    var calcHotClimate by remember {
        mutableStateOf(false)
    }

    val calculatedGoal = viewModel.calculateRecommendedGoal(calcWeightKg, calcActivity, calcHotClimate)

    LazyColumn(
        modifier = modifier
            .testTag("goal_calculator_screen")
            .fillMaxSize()
            .padding(horizontal = 18.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 100.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        item {
            Column {
                Text(
                    text = "Personal Target 🎯",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    color = TextSlateMuted
                )
                Text(
                    text = "Daily Hydration Goal",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = TextSlatePrimary
                )
                Text(
                    text = "Customize your target volume or calculate from body biology",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    color = TextSlateMuted
                )
            }
        }

        // Active Goal Card with Slider
        item {
            ClayCard(
                modifier = Modifier
                    .testTag("active_goal_card")
                    .fillMaxWidth(),
                shape = RoundedCornerShape(28.dp),
                backgroundColor = Color.White,
                elevation = 8.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Current Daily Target",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = TextSlateMuted
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Box(
                        modifier = Modifier
                            .shadow(6.dp, RoundedCornerShape(22.dp), ambientColor = Color(0x220284C7))
                            .clip(RoundedCornerShape(22.dp))
                            .background(Color(0xFFF0F9FF))
                            .border(1.5.dp, Color(0xFFBAE6FD), RoundedCornerShape(22.dp))
                            .padding(horizontal = 24.dp, vertical = 10.dp)
                    ) {
                        Row(verticalAlignment = Alignment.Bottom) {
                            Text(
                                text = "${customGoal.toInt()}",
                                fontSize = 36.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = WaterDarkDeep
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "ml / day",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = WaterPrimary,
                                modifier = Modifier.padding(bottom = 6.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Slider(
                        value = customGoal,
                        onValueChange = {
                            val rounded = ((it / 50).toInt() * 50).toFloat()
                            customGoal = rounded
                            viewModel.updateDailyGoal(rounded.toInt())
                        },
                        valueRange = 1000f..5000f,
                        steps = 79,
                        colors = SliderDefaults.colors(
                            thumbColor = WaterPrimary,
                            activeTrackColor = WaterPrimary,
                            inactiveTrackColor = Color(0xFFE2E8F0)
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp)
                            .testTag("goal_slider")
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "1,000 ml", fontSize = 11.sp, color = TextSlateMuted)
                        Text(text = "3,000 ml", fontSize = 11.sp, color = TextSlateMuted)
                        Text(text = "5,000 ml", fontSize = 11.sp, color = TextSlateMuted)
                    }
                }
            }
        }

        // Smart Hydration Calculator
        item {
            ClayCard(
                modifier = Modifier
                    .testTag("calculator_card")
                    .fillMaxWidth(),
                shape = RoundedCornerShape(28.dp),
                backgroundColor = Color.White,
                elevation = 8.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Smart Body Calculator",
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextSlatePrimary
                            )
                            Text(
                                text = "Based on clinical hydration formulas",
                                fontSize = 12.sp,
                                color = TextSlateMuted
                            )
                        }
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFE0F2FE)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Calculate,
                                contentDescription = null,
                                tint = WaterPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    // 1. Weight Selector
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Rounded.MonitorWeight,
                                contentDescription = null,
                                tint = WaterPrimary,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Body Weight",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = TextSlatePrimary
                            )
                        }

                        Text(
                            text = "$calcWeightKg kg",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = WaterDarkDeep
                        )
                    }

                    Slider(
                        value = calcWeightKg.toFloat(),
                        onValueChange = { calcWeightKg = it.toInt() },
                        valueRange = 40f..140f,
                        steps = 99,
                        colors = SliderDefaults.colors(
                            thumbColor = WaterPrimary,
                            activeTrackColor = WaterPrimary,
                            inactiveTrackColor = Color(0xFFE2E8F0)
                        ),
                        modifier = Modifier.padding(horizontal = 8.dp)
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // 2. Activity Level
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Rounded.FitnessCenter,
                            contentDescription = null,
                            tint = WaterPrimary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Daily Activity",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = TextSlatePrimary
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    val activities = listOf("Light", "Moderate", "Active", "Athlete")
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        activities.forEach { act ->
                            val isSelected = act == calcActivity
                            FluffyPill(
                                selected = isSelected,
                                onClick = { calcActivity = act },
                                selectedColor = WaterPrimary,
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(
                                    text = act,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    color = if (isSelected) Color.White else TextSlatePrimary,
                                    modifier = Modifier.padding(vertical = 8.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // 3. Climate Toggle
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Rounded.Thermostat,
                                contentDescription = null,
                                tint = WaterPrimary,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "Warm / Humid Climate",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = TextSlatePrimary
                                )
                                Text(
                                    text = "+400ml for higher perspiration",
                                    fontSize = 11.sp,
                                    color = TextSlateMuted
                                )
                            }
                        }

                        Switch(
                            checked = calcHotClimate,
                            onCheckedChange = { calcHotClimate = it },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = WaterPrimary
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // Result Pill & Apply Button
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(20.dp))
                            .background(Color(0xFFF0FDF4))
                            .border(1.dp, Color(0xFFA7F3D0), RoundedCornerShape(20.dp))
                            .padding(14.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "Recommended Intake",
                                    fontSize = 12.sp,
                                    color = TextSlateMuted
                                )
                                Text(
                                    text = "$calculatedGoal ml / day",
                                    fontSize = 20.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = PastelMintDark
                                )
                            }

                            ClayButton(
                                onClick = {
                                    customGoal = calculatedGoal.toFloat()
                                    viewModel.updateDailyGoal(calculatedGoal)
                                    viewModel.updateSettings(
                                        settings.copy(
                                            dailyGoalMl = calculatedGoal,
                                            userWeightKg = calcWeightKg,
                                            activityLevel = calcActivity
                                        )
                                    )
                                    Toast.makeText(context, "Goal updated to ${calculatedGoal}ml! 💧", Toast.LENGTH_SHORT).show()
                                },
                                backgroundColor = PastelMintDark,
                                shape = RoundedCornerShape(18.dp),
                                elevation = 4.dp
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.CheckCircle,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "Apply",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
