package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.LocalFireDepartment
import androidx.compose.material.icons.rounded.WaterDrop
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.MainViewModel
import com.example.ui.components.ClayCustomAddDialog
import com.example.ui.components.ClayQuickAddRow
import com.example.ui.components.ClayTodayLogsList
import com.example.ui.components.ClayWaterVessel
import com.example.ui.components.ClayWeeklyChart
import com.example.ui.theme.PastelPeachDark
import com.example.ui.theme.TextSlateMuted
import com.example.ui.theme.TextSlatePrimary
import com.example.ui.theme.WaterDarkDeep
import com.example.ui.theme.WaterPrimary
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@Composable
fun HomeScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val todayTotalIntake by viewModel.todayTotalIntake.collectAsStateWithLifecycle()
    val userSettings by viewModel.userSettings.collectAsStateWithLifecycle()
    val todayLogs by viewModel.todayLogs.collectAsStateWithLifecycle()
    val weeklyData by viewModel.weeklyData.collectAsStateWithLifecycle()
    val selectedDate by viewModel.selectedDate.collectAsStateWithLifecycle()
    val selectedBeverage by viewModel.selectedBeverage.collectAsStateWithLifecycle()
    val showCustomDialog by viewModel.showCustomAddDialog.collectAsStateWithLifecycle()
    val currentStreak by viewModel.currentStreak.collectAsStateWithLifecycle()

    val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    val greeting = when (hour) {
        in 5..11 -> "Good morning"
        in 12..17 -> "Good afternoon"
        else -> "Good evening"
    }

    val displayDate = SimpleDateFormat("EEEE, MMMM d", Locale.getDefault()).format(Date())

    LazyColumn(
        modifier = modifier
            .testTag("home_screen_lazy_column")
            .fillMaxSize()
            .padding(horizontal = 18.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 100.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        // Clay Top Bar Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "$greeting ✨",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium,
                        color = TextSlateMuted
                    )
                    Text(
                        text = "AquaClay Tracker",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = TextSlatePrimary
                    )
                    Text(
                        text = displayDate,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = WaterPrimary
                    )
                }

                // Fluffy Streak Pill
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(Color(0xFFFFF7ED))
                        .border(1.dp, Color(0xFFFED7AA), RoundedCornerShape(20.dp))
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Rounded.LocalFireDepartment,
                            contentDescription = null,
                            tint = PastelPeachDark,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "$currentStreak ${if (currentStreak == 1) "day" else "days"}",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = PastelPeachDark
                        )
                    }
                }
            }
        }

        // Centerpiece Animated Water Vessel
        item {
            ClayWaterVessel(
                currentIntakeMl = todayTotalIntake,
                dailyGoalMl = userSettings.dailyGoalMl,
                onVesselClick = {
                    viewModel.setCustomAddDialogVisible(true)
                }
            )
        }

        // Quick Add Presets Row
        item {
            ClayQuickAddRow(
                selectedBeverage = selectedBeverage,
                onBeverageSelected = { viewModel.selectBeverage(it) },
                onQuickAdd = { amount ->
                    viewModel.logWater(amount, selectedBeverage)
                },
                onCustomAddClick = {
                    viewModel.setCustomAddDialogVisible(true)
                }
            )
        }

        // Weekly 7-Day Chart
        item {
            ClayWeeklyChart(
                weeklyData = weeklyData,
                selectedDate = selectedDate,
                onDaySelected = { date ->
                    viewModel.selectDate(date)
                }
            )
        }

        // Today's Drink History
        item {
            ClayTodayLogsList(
                logs = todayLogs,
                onDeleteLog = { log ->
                    viewModel.deleteLog(log)
                }
            )
        }
    }

    // Custom Add Amount Dialog
    if (showCustomDialog) {
        ClayCustomAddDialog(
            initialBeverage = selectedBeverage,
            onDismiss = { viewModel.setCustomAddDialogVisible(false) },
            onConfirm = { amount, beverage ->
                viewModel.logWater(amount, beverage)
                viewModel.setCustomAddDialogVisible(false)
            }
        )
    }
}
