package com.example.ui.screens

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Alarm
import androidx.compose.material.icons.rounded.Bedtime
import androidx.compose.material.icons.rounded.Lightbulb
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.Send
import androidx.compose.material.icons.rounded.Vibration
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material.icons.rounded.WbSunny
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.reminder.WaterReminderReceiver
import com.example.ui.MainViewModel
import com.example.ui.clay.ClayButton
import com.example.ui.clay.ClayCard
import com.example.ui.clay.FluffyPill
import com.example.ui.theme.PastelLemonDark
import com.example.ui.theme.PastelMintDark
import com.example.ui.theme.TextSlateMuted
import com.example.ui.theme.TextSlatePrimary
import com.example.ui.theme.TextSlateSecondary
import com.example.ui.theme.WaterDarkDeep
import com.example.ui.theme.WaterPrimary

@Composable
fun RemindersScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val settings by viewModel.userSettings.collectAsStateWithLifecycle()

    // Permission launcher for Android 13+
    var hasNotificationPermission by remember {
        mutableStateOf(
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.POST_NOTIFICATIONS
                ) == PackageManager.PERMISSION_GRANTED
            } else {
                true
            }
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        hasNotificationPermission = isGranted
        if (isGranted) {
            Toast.makeText(context, "Notifications enabled! 💧", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(
                context,
                "Notification permission is needed for reminders",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    LazyColumn(
        modifier = modifier
            .testTag("reminders_screen")
            .fillMaxSize()
            .padding(horizontal = 18.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 100.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        item {
            Column {
                Text(
                    text = "Gentle Sips ⏰",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    color = TextSlateMuted
                )
                Text(
                    text = "Custom Reminders",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = TextSlatePrimary
                )
                Text(
                    text = "Keep your water rhythm flowing with scheduled clay alerts",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    color = TextSlateMuted
                )
            }
        }

        // Notification Permission Card (if not granted)
        if (!hasNotificationPermission && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            item {
                ClayCard(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp),
                    backgroundColor = Color(0xFFFEF2F2),
                    borderColor = Color(0xFFFECACA),
                    elevation = 6.dp
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            modifier = Modifier.weight(1f),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Notifications,
                                contentDescription = null,
                                tint = Color(0xFFDC2626),
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "Permission Needed",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = Color(0xFF991B1B)
                                )
                                Text(
                                    text = "Allow notifications to receive water alerts",
                                    fontSize = 11.sp,
                                    color = Color(0xFFB91C1C)
                                )
                            }
                        }

                        ClayButton(
                            onClick = {
                                permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                            },
                            backgroundColor = Color(0xFFDC2626),
                            shape = RoundedCornerShape(16.dp),
                            elevation = 4.dp
                        ) {
                            Text(
                                text = "Enable",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                            )
                        }
                    }
                }
            }
        }

        // Master Switch Card
        item {
            ClayCard(
                modifier = Modifier
                    .testTag("reminder_master_switch_card")
                    .fillMaxWidth(),
                shape = RoundedCornerShape(28.dp),
                backgroundColor = Color.White,
                elevation = 8.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(46.dp)
                                .clip(CircleShape)
                                .background(if (settings.reminderEnabled) Color(0xFFE0F2FE) else Color(0xFFF1F5F9)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.NotificationsActive,
                                contentDescription = null,
                                tint = if (settings.reminderEnabled) WaterPrimary else TextSlateMuted,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column {
                            Text(
                                text = "Hydration Reminders",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextSlatePrimary
                            )
                            Text(
                                text = if (settings.reminderEnabled) "Active throughout the day" else "Reminders paused",
                                fontSize = 12.sp,
                                color = if (settings.reminderEnabled) Color(0xFF059669) else TextSlateMuted
                            )
                        }
                    }

                    Switch(
                        checked = settings.reminderEnabled,
                        onCheckedChange = { isChecked ->
                            if (isChecked && !hasNotificationPermission && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                            }
                            viewModel.toggleReminders(isChecked)
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = WaterPrimary,
                            uncheckedThumbColor = Color.White,
                            uncheckedTrackColor = Color(0xFFCBD5E1)
                        ),
                        modifier = Modifier.testTag("reminder_switch")
                    )
                }
            }
        }

        // Interval Setting Card
        item {
            ClayCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(28.dp),
                backgroundColor = Color.White,
                elevation = 8.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp)
                ) {
                    Text(
                        text = "Reminder Interval",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextSlatePrimary
                    )
                    Text(
                        text = "How frequently would you like a friendly nudge?",
                        fontSize = 12.sp,
                        color = TextSlateMuted
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    val intervals = listOf(
                        30 to "30 mins",
                        45 to "45 mins",
                        60 to "1 hour",
                        90 to "90 mins",
                        120 to "2 hours",
                        180 to "3 hours"
                    )

                    // 2x3 Grid of Fluffy Pills
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        intervals.chunked(3).forEach { rowIntervals ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                rowIntervals.forEach { (mins, label) ->
                                    val isSelected = settings.reminderIntervalMinutes == mins
                                    FluffyPill(
                                        selected = isSelected,
                                        onClick = { viewModel.setReminderInterval(mins) },
                                        selectedColor = WaterPrimary,
                                        modifier = Modifier
                                            .weight(1f)
                                            .testTag("interval_${mins}m")
                                    ) {
                                        Text(
                                            text = label,
                                            fontSize = 12.sp,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                            color = if (isSelected) Color.White else TextSlatePrimary,
                                            modifier = Modifier.padding(vertical = 10.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Active Hours (Wake up & Sleep time)
        item {
            ClayCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(28.dp),
                backgroundColor = Color.White,
                elevation = 8.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp)
                ) {
                    Text(
                        text = "Active Waking Window",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextSlatePrimary
                    )
                    Text(
                        text = "No reminders will buzz while you sleep",
                        fontSize = 12.sp,
                        color = TextSlateMuted
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Wake Time Box
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(20.dp))
                                .background(Color(0xFFFFFBEB))
                                .border(1.dp, Color(0xFFFDE68A), RoundedCornerShape(20.dp))
                                .padding(14.dp)
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Rounded.WbSunny,
                                        contentDescription = null,
                                        tint = PastelLemonDark,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "Wake Up",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = PastelLemonDark
                                    )
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = String.format("%02d:%02d AM", settings.wakeHour, settings.wakeMinute),
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = TextSlatePrimary
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    ClayButton(
                                        onClick = {
                                            val newHour = (settings.wakeHour - 1).coerceIn(4, 11)
                                            viewModel.setWakeSleepTimes(newHour, settings.wakeMinute, settings.sleepHour, settings.sleepMinute)
                                        },
                                        modifier = Modifier.size(32.dp),
                                        shape = CircleShape,
                                        backgroundColor = Color.White,
                                        contentColor = TextSlatePrimary,
                                        elevation = 2.dp
                                    ) {
                                        Text("-", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                    }
                                    ClayButton(
                                        onClick = {
                                            val newHour = (settings.wakeHour + 1).coerceIn(4, 11)
                                            viewModel.setWakeSleepTimes(newHour, settings.wakeMinute, settings.sleepHour, settings.sleepMinute)
                                        },
                                        modifier = Modifier.size(32.dp),
                                        shape = CircleShape,
                                        backgroundColor = Color.White,
                                        contentColor = TextSlatePrimary,
                                        elevation = 2.dp
                                    ) {
                                        Text("+", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                    }
                                }
                            }
                        }

                        // Sleep Time Box
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(20.dp))
                                .background(Color(0xFFF5F3FF))
                                .border(1.dp, Color(0xFFDDD6FE), RoundedCornerShape(20.dp))
                                .padding(14.dp)
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Rounded.Bedtime,
                                        contentDescription = null,
                                        tint = Color(0xFF7C3AED),
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "Bedtime",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = Color(0xFF7C3AED)
                                    )
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                val displaySleepHour = if (settings.sleepHour > 12) settings.sleepHour - 12 else settings.sleepHour
                                Text(
                                    text = String.format("%02d:%02d PM", displaySleepHour, settings.sleepMinute),
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = TextSlatePrimary
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    ClayButton(
                                        onClick = {
                                            val newHour = (settings.sleepHour - 1).coerceIn(19, 23)
                                            viewModel.setWakeSleepTimes(settings.wakeHour, settings.wakeMinute, newHour, settings.sleepMinute)
                                        },
                                        modifier = Modifier.size(32.dp),
                                        shape = CircleShape,
                                        backgroundColor = Color.White,
                                        contentColor = TextSlatePrimary,
                                        elevation = 2.dp
                                    ) {
                                        Text("-", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                    }
                                    ClayButton(
                                        onClick = {
                                            val newHour = (settings.sleepHour + 1).coerceIn(19, 23)
                                            viewModel.setWakeSleepTimes(settings.wakeHour, settings.wakeMinute, newHour, settings.sleepMinute)
                                        },
                                        modifier = Modifier.size(32.dp),
                                        shape = CircleShape,
                                        backgroundColor = Color.White,
                                        contentColor = TextSlatePrimary,
                                        elevation = 2.dp
                                    ) {
                                        Text("+", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Alert Style (Vibration & Sound)
        item {
            ClayCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(28.dp),
                backgroundColor = Color.White,
                elevation = 8.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text(
                        text = "Alert Preferences",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextSlatePrimary
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Rounded.Vibration,
                                contentDescription = null,
                                tint = WaterPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "Haptic Vibration",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = TextSlatePrimary
                            )
                        }
                        Switch(
                            checked = settings.vibrateEnabled,
                            onCheckedChange = {
                                viewModel.updateSettings(settings.copy(vibrateEnabled = it))
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = WaterPrimary
                            )
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Rounded.VolumeUp,
                                contentDescription = null,
                                tint = WaterPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "Sound Effect",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = TextSlatePrimary
                            )
                        }
                        Switch(
                            checked = settings.soundEnabled,
                            onCheckedChange = {
                                viewModel.updateSettings(settings.copy(soundEnabled = it))
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = WaterPrimary
                            )
                        )
                    }
                }
            }
        }

        // Test Notification Button
        item {
            ClayButton(
                onClick = {
                    if (!hasNotificationPermission && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    } else {
                        // Trigger immediate test notification via broadcast
                        val intent = android.content.Intent(context, WaterReminderReceiver::class.java).apply {
                            action = WaterReminderReceiver.ACTION_WATER_REMINDER
                        }
                        context.sendBroadcast(intent)
                        Toast.makeText(context, "Test reminder sent! Check your notification bar 💧", Toast.LENGTH_SHORT).show()
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .testTag("test_reminder_button"),
                backgroundColor = Color(0xFF0284C7),
                shape = RoundedCornerShape(24.dp),
                elevation = 6.dp
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Rounded.Send,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Send Test Reminder Now",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }
        }

        // Fluffy Clay Tip Card
        item {
            ClayCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                backgroundColor = Color(0xFFF0FDF4),
                borderColor = Color(0xFFA7F3D0),
                elevation = 4.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Lightbulb,
                        contentDescription = null,
                        tint = PastelMintDark,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "Did You Know?",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = PastelMintDark
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Drinking water throughout the day rather than all at once allows your kidneys to absorb nutrients and hydrate tissues properly.",
                            fontSize = 11.sp,
                            color = TextSlateSecondary,
                            lineHeight = 16.sp
                        )
                    }
                }
            }
        }
    }
}
