package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.Insights
import androidx.compose.material.icons.rounded.LocalFireDepartment
import androidx.compose.material.icons.rounded.PieChart
import androidx.compose.material.icons.rounded.WaterDrop
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.BeverageType
import com.example.ui.MainViewModel
import com.example.ui.clay.ClayCard
import com.example.ui.components.ClayTodayLogsList
import com.example.ui.components.ClayWeeklyChart
import com.example.ui.theme.PastelLilacDark
import com.example.ui.theme.PastelMintDark
import com.example.ui.theme.PastelPeachDark
import com.example.ui.theme.TextSlateMuted
import com.example.ui.theme.TextSlatePrimary
import com.example.ui.theme.WaterDarkDeep
import com.example.ui.theme.WaterPastelSky
import com.example.ui.theme.WaterPrimary

@Composable
fun StatsScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val allLogs by viewModel.allLogs.collectAsStateWithLifecycle()
    val weeklyData by viewModel.weeklyData.collectAsStateWithLifecycle()
    val selectedDate by viewModel.selectedDate.collectAsStateWithLifecycle()
    val selectedDateLogs by viewModel.selectedDateLogs.collectAsStateWithLifecycle()
    val currentStreak by viewModel.currentStreak.collectAsStateWithLifecycle()
    val userSettings by viewModel.userSettings.collectAsStateWithLifecycle()

    val totalIntakeAllTime = allLogs.sumOf { it.amountMl }
    val totalLiters = totalIntakeAllTime / 1000f

    val daysWithLogs = allLogs.map { it.dateString }.distinct().size.coerceAtLeast(1)
    val dailyAvg = (totalIntakeAllTime / daysWithLogs)

    // Beverage distribution
    val beverageCounts = allLogs.groupBy { it.beverageType }
        .mapValues { entry -> entry.value.sumOf { it.amountMl } }

    LazyColumn(
        modifier = modifier
            .testTag("stats_screen")
            .fillMaxSize()
            .padding(horizontal = 18.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 100.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        item {
            Column {
                Text(
                    text = "Hydration Insights 📊",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    color = TextSlateMuted
                )
                Text(
                    text = "Analytics & Streaks",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = TextSlatePrimary
                )
                Text(
                    text = "Track your long-term fluid balance and achievements",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    color = TextSlateMuted
                )
            }
        }

        // Summary Metric Tiles (2x2 Clay Grid)
        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Total Volume
                    ClayCard(
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(24.dp),
                        backgroundColor = Color(0xFFF0F9FF),
                        borderColor = Color(0xFFBAE6FD),
                        elevation = 6.dp
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFFBAE6FD)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.WaterDrop,
                                    contentDescription = null,
                                    tint = WaterPrimary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = String.format("%.1f L", totalLiters),
                                fontSize = 22.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = WaterDarkDeep
                            )
                            Text(
                                text = "Total Logged",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium,
                                color = TextSlateMuted
                            )
                        }
                    }

                    // Daily Average
                    ClayCard(
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(24.dp),
                        backgroundColor = Color(0xFFF0FDF4),
                        borderColor = Color(0xFFA7F3D0),
                        elevation = 6.dp
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFFA7F3D0)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Insights,
                                    contentDescription = null,
                                    tint = PastelMintDark,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = "${dailyAvg} ml",
                                fontSize = 22.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = PastelMintDark
                            )
                            Text(
                                text = "Daily Average",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium,
                                color = TextSlateMuted
                            )
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Streak
                    ClayCard(
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(24.dp),
                        backgroundColor = Color(0xFFFFF7ED),
                        borderColor = Color(0xFFFED7AA),
                        elevation = 6.dp
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFFFED7AA)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.LocalFireDepartment,
                                    contentDescription = null,
                                    tint = PastelPeachDark,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = "$currentStreak days",
                                fontSize = 22.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = PastelPeachDark
                            )
                            Text(
                                text = "Active Streak",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium,
                                color = TextSlateMuted
                            )
                        }
                    }

                    // Total Sips / Entries
                    ClayCard(
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(24.dp),
                        backgroundColor = Color(0xFFF5F3FF),
                        borderColor = Color(0xFFDDD6FE),
                        elevation = 6.dp
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFFDDD6FE)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.EmojiEvents,
                                    contentDescription = null,
                                    tint = PastelLilacDark,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = "${allLogs.size}",
                                fontSize = 22.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = PastelLilacDark
                            )
                            Text(
                                text = "Total Drinks",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium,
                                color = TextSlateMuted
                            )
                        }
                    }
                }
            }
        }

        // Weekly Interactive Chart
        item {
            ClayWeeklyChart(
                weeklyData = weeklyData,
                selectedDate = selectedDate,
                onDaySelected = { date ->
                    viewModel.selectDate(date)
                }
            )
        }

        // Beverage Type Breakdown
        item {
            ClayCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(28.dp),
                backgroundColor = Color.White,
                elevation = 8.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Drink Varieties",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextSlatePrimary
                        )
                        Icon(
                            imageVector = Icons.Rounded.PieChart,
                            contentDescription = null,
                            tint = WaterPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    if (allLogs.isEmpty()) {
                        Text(
                            text = "Log drinks to see your beverage breakdown",
                            fontSize = 12.sp,
                            color = TextSlateMuted
                        )
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            BeverageType.entries.forEach { bev ->
                                val amount = beverageCounts[bev] ?: 0
                                if (amount > 0) {
                                    val percentage = (amount.toFloat() / totalIntakeAllTime.toFloat())

                                    Column {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(
                                                text = "${bev.emoji} ${bev.displayName}",
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.SemiBold,
                                                color = TextSlatePrimary
                                            )
                                            Text(
                                                text = "${amount}ml (${(percentage * 100).toInt()}%)",
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color(bev.accentHex)
                                            )
                                        }

                                        Spacer(modifier = Modifier.height(4.dp))

                                        LinearProgressIndicator(
                                            progress = { percentage },
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(8.dp)
                                                .clip(RoundedCornerShape(4.dp)),
                                            color = Color(bev.accentHex),
                                            trackColor = Color(0xFFF1F5F9),
                                            strokeCap = StrokeCap.Round
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Selected Date Logged Drinks
        item {
            ClayTodayLogsList(
                logs = selectedDateLogs,
                onDeleteLog = { viewModel.deleteLog(it) }
            )
        }
    }
}
