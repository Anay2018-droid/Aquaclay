package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Clay and Water Soft Pastel Color Palette
val ClayBgLight = Color(0xFFF1F5F9) // Soft airy cloud background
val ClaySurfaceLight = Color(0xFFFFFFFF) // Puffy pure white surface
val ClaySurfaceVariant = Color(0xFFE2E8F0)

// Water Blues & Cyans
val WaterPastelSky = Color(0xFF7DD3FC) // Soft sky water
val WaterPrimary = Color(0xFF0284C7) // Vibrant deep water
val WaterPrimaryContainer = Color(0xFFE0F2FE) // Very soft cyan foam
val WaterSecondary = Color(0xFF38BDF8) // Bright ripple blue
val WaterDarkDeep = Color(0xFF0369A1) // Deep ocean for contrast
val WaterWaveCrest = Color(0xFFBAE6FD) // Light crest wave

// Pastel Accents for Beverages & Highlights
val PastelMint = Color(0xFFA7F3D0)
val PastelMintDark = Color(0xFF059669)
val PastelMintContainer = Color(0xFFECFDF5)

val PastelLilac = Color(0xFFDDD6FE)
val PastelLilacDark = Color(0xFF7C3AED)
val PastelLilacContainer = Color(0xFFF5F3FF)

val PastelPeach = Color(0xFFFED7AA)
val PastelPeachDark = Color(0xFFEA580C)
val PastelPeachContainer = Color(0xFFFFF7ED)

val PastelLemon = Color(0xFFFEF08A)
val PastelLemonDark = Color(0xFFCA8A04)

val PastelRose = Color(0xFFFBCFE8)
val PastelRoseDark = Color(0xFFDB2777)

// Text Slate
val TextSlatePrimary = Color(0xFF0F172A)
val TextSlateSecondary = Color(0xFF475569)
val TextSlateMuted = Color(0xFF94A3B8)

// Clay Shadows & Glows
val ClayShadowDark = Color(0x240F172A) // 14% dark drop shadow
val ClayShadowLight = Color(0xCCFFFFFF) // 80% white top-left highlight
val ClayOutlineSoft = Color(0xFFE2E8F0)
