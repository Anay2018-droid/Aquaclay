package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColorScheme = lightColorScheme(
    primary = WaterPrimary,
    onPrimary = Color.White,
    primaryContainer = WaterPrimaryContainer,
    onPrimaryContainer = WaterDarkDeep,
    secondary = WaterSecondary,
    onSecondary = Color.White,
    secondaryContainer = WaterWaveCrest,
    onSecondaryContainer = WaterDarkDeep,
    tertiary = PastelMintDark,
    onTertiary = Color.White,
    tertiaryContainer = PastelMintContainer,
    onTertiaryContainer = PastelMintDark,
    background = ClayBgLight,
    onBackground = TextSlatePrimary,
    surface = ClaySurfaceLight,
    onSurface = TextSlatePrimary,
    surfaceVariant = Color(0xFFF8FAFC),
    onSurfaceVariant = TextSlateSecondary,
    outline = ClayOutlineSoft,
    outlineVariant = Color(0xFFE2E8F0)
)

private val DarkColorScheme = darkColorScheme(
    primary = WaterPastelSky,
    onPrimary = Color(0xFF082F49),
    primaryContainer = Color(0xFF075985),
    onPrimaryContainer = Color(0xFFE0F2FE),
    secondary = WaterWaveCrest,
    onSecondary = Color(0xFF0C4A6E),
    secondaryContainer = Color(0xFF0369A1),
    onSecondaryContainer = Color(0xFFE0F2FE),
    tertiary = PastelMint,
    onTertiary = Color(0xFF064E3B),
    background = Color(0xFF0F172A),
    onBackground = Color(0xFFF1F5F9),
    surface = Color(0xFF1E293B),
    onSurface = Color(0xFFF1F5F9),
    surfaceVariant = Color(0xFF334155),
    onSurfaceVariant = Color(0xFFCBD5E1),
    outline = Color(0xFF475569)
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Keep consistent pastel clay aesthetic
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
